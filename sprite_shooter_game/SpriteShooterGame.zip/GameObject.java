
import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;

public class GameObject extends JPanel implements Runnable  {

    public void paint(Graphics2D g) {

    }
    
    public void keyPressed(String key) {

    }
    
    public void keyReleased(String key) {
        
    }

    public void run() {
        
    }
}
