// a LinkedQueue is first in first out abstract data type
// imagine a line for a movie, it's exactly like that
public class LinkedQueue {
	Node head;
	Node tail;

	public void enqueue(Enemy i) {
		Node bago = new Node(i);
		if (head == null) {
			head = bago;
			tail = bago;
		} else {
			tail.next = bago;
			tail = bago;
		}
		
	}

	public Enemy dequeue() {
		if (head != null) {
			Enemy result = head.data;
			head = head.next;
			if (head == null) {
				tail = null;
			}
			return result;
		} else {
			return null;  // or some other value that indicates na walang nakuha
                              // return null when dealing with Objects
		}
	}
/*
	public void decreaseCount(){
           Node rover = head;
           while (rover != null) {
               rover.count -= 1;
               rover = rover.next;      // go to the next node
           }		
	}
*/
	// silip lang
	public Enemy peek() {
		if (head != null) {
			Enemy result = head.data;
			return result;			
		} else {
			return null; // or some other value that indicates na walang nakuha
                             // return null when dealing with Objects
		}
	
	}
/*
      public void visualizeQueue() {
           Node rover = head;
           while (rover != null) {
               rover.visualizeNode();   // prEnemy the node
               rover = rover.next;      // go to the next node
           }
      }

*/
	public boolean isEmpty() {
		return head == null;
	}
}