public class Fire extends Sprite{
	private final int BOARD_WIDTH = 390;	
	private final int MISSILE_SPEED = 2;

	public Fire(int x, int y){
		super(x, y);

		initFire();
	}

	private void initFire(){
		loadImage("fire.png");
		getImageDimensions();
	}

	public void move(){
		x += MISSILE_SPEED;

		if(x > BOARD_WIDTH){
			vis = false;
		}
	}
}