public class Node{
	Enemy data;   // change this datatype to whatever you are storing
	Node next;
    public Node(Enemy pasok) {
        int x = pasok.x;
        int y = pasok.y;
        data = new Enemy(x, y);   // <-- for integers and Strings 
        data.x = pasok.x;
        data.y = pasok.y;
		
        // when dealing with objects, make a deep copy
        // for example, if you’re dealing with Enemys, deep copy looks like this:
        // data = new Enemy();  // make a different object for the Node  
        // data.hp = pasok.hp;   // copy all attributes
    }
}
