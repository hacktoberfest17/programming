import java.awt.EventQueue;
import javax.swing.JFrame;

public class SpriteShooterGame extends JFrame{
	//class constructor, initialization
	public SpriteShooterGame(){
		initUI();
	}

	private void initUI(){
		add(new Board());

		setResizable(false);
		pack();

		setTitle("MP2 - Kirby Game");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run(){
				SpriteShooterGame ex = new SpriteShooterGame();
				ex.setVisible(true);
			}
		});
	}
}